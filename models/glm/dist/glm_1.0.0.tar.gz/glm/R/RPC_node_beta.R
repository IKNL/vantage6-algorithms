#' RPC call for the first data loop of the federated GLM
#'
#' @param Data dataframe containing the data
#' @param weights an optional vector of ‘prior weights’ to be used in the
#' fitting process. Should be NULL or a numeric vector.
#' @param master a list of parameters used to compute the GLM
#'
#' @return GLM partials
#'
RPC_node_beta <- function(Data, weights = NULL, master = NULL) {

    vtg::log$debug("Initializing node beta...")

    # specify data types for the columns in the data
    if(!is.null(master$types)){
      Data <- format_data(Data,master$types)
    }

    formula <- master$formula
    family <- master$family
    dstar <- master$dstar

    #extract y and X varibales name from formula
    y <- eval(formula[[2]], envir = Data)
    # create a model matrix
    X <- model.matrix(formula, data = Data)
    # extract the offset from formula (if exists)
    offset <- model.offset(model.frame(formula, data = Data))

    # functions of the family required (gaussian, poisson, logistic,...)
    if(family=='rs.poi'){
        if(is.null(dstar)){
            vtg::log$debug("expected count required for relative survival")
            return()
        }
        family <- poisson()
        family$family <- "rs.poi"
        family$link <- "glm relative survival model with Poisson error"
        family$linkfun <- function(mu) log(mu - dstar)
        family$linkinv <- function(eta) dstar + exp(eta)
        dstar=eval(as.name(dstar),Data)
    } else {
        if (is.character(family))
            family <- get(family, mode = "function", envir = parent.frame())
        if (is.function(family))
            family <- family()
        if (is.null(family$family))
            stop(glue::glue("family '{family}' not recognized"))
    }

    if (is.null(weights)) weights <- rep.int(1, nrow(X))
    if (is.null(offset)) offset <- rep.int(0, nrow(X))

    # (!) `nobs` and `nvars` needed by the initialize expression below
    nobs <- nrow(X)
    nvars <- ncol(X)

    if (master$iter==1) {
        vtg::log$debug("First iteration. Initializing variables.")
        etastart = NULL
        if(family$family=="rs.poi")
        {
            mustart= pmax(y,dstar) + 0.1
        } else {
            eval(family$initialize)
        } # initializes n and fitted values mustart
        eta = family$linkfun(mustart) # we then initialize eta with this
    } else {
        eta = (X %*% master$coef[,ncol(master$coef)]) + offset #update eta
    }

    vtg::log$debug("Calculating the Betas.")
    mu <-  family$linkinv(eta)
    varg <- family$variance(mu)
    gprime <- family$mu.eta(eta)

    # calculate z
    z <- (eta - offset) + (y - mu) / gprime
    # update the weights
    W <- weights * as.vector(gprime^2 / varg)
    #calculate the dispersion matrix
    dispersion <- sum(W *((y - mu) / family$mu.eta(eta))^2)

    output <- list(v1 = crossprod(X, W*X), v2 = crossprod(X, W*z),
                   dispersion = dispersion, nobs = nobs, nvars = nvars,
                   wt1 = sum(weights * y), wt2 = sum(weights))

    return(output)
}
