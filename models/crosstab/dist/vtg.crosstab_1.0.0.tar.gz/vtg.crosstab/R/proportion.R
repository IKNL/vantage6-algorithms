#' @export
#'
proportion <- function(output, margin) prop.table(output, margin)