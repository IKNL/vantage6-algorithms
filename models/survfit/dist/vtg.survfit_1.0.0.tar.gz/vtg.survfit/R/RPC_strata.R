RPC_strata=function(data,strata){
    return(unique(data[,strata]))
}