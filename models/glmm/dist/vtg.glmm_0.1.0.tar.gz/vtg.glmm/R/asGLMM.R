as.GLMM <- function(result, data=NULL){

    fixed_effects <- result$fixed_effects

    random_effect <- result$random_effect


    out <- list()

    if(!is.null(data)){

        mf <- lme4::glFormula(covars)

    }


}