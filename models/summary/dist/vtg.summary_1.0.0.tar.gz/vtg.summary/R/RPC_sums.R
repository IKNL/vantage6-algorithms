#' @export
#'
RPC_sums <- function(data, col, threshold = 5L){
    uniq.col <- unique(col)
    cols.in.data <- uniq.col[uniq.col %in% names(data)]
    out <- vector("list", length(cols.in.data))
    names(out) <- cols.in.data
    data <- na.omit(data[, cols.in.data])
    # someitmes can have a column that is completely NA...
    if(!length(data)){
        out <- NULL
    }else{
        for(j in col){
            out[[j]] <- if(!is.factor(data[,j])){
                sum(data[,j])
            }
        }
    }
    out
}
